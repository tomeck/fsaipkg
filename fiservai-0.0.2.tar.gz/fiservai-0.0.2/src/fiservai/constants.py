BASE_URL = "https://connect-dev.fiservapis.com/ai-gateway/v1"
MODELS_URL = BASE_URL+"/deployments"
MAX_TOKENS = 500
DEFAULT_SYSTEM_PROMPT = "You are a courteous agent who answers questions.  You will do no harm and you will not make up answers.  You will only provide answers that are true and accurate  If you don't know the answer, just say 'Sorry, I'm not sure.'  Think step by step to be sure you have the right answer the first time."
DEFAULT_MODEL_NAME = "azure-openai-3.5-turbo-16-east"