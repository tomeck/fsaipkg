import asyncio
import hashlib
import hmac
import base64
import time
import random
import string
from typing import List, Union
import openai
import requests
from .constants import *

class FiservAI(openai.AsyncOpenAI):
    __BASE_URL = BASE_URL
    __MODELS_URL = BASE_URL+"/deployments"
    __MAX_TOKENS = MAX_TOKENS
    __DEFAULT_SYSTEM_PROMPT = DEFAULT_SYSTEM_PROMPT
    __DEFAULT_MODEL_NAME = DEFAULT_MODEL_NAME
    
    __api_key : str = None
    __api_secret : str = None
    __model_name : str = None

    def __init__(self, api_key:str, api_secret:str, model_name:str = __DEFAULT_MODEL_NAME):
        super().__init__(api_key="", base_url=self.__BASE_URL)
        self.__api_key = api_key
        self.__api_secret = api_secret
        self.__model_name = model_name

    def __generateRandomString(self):
        """
        Generates a random string of length 32 using ASCII letters and digits.

        Returns:
            str: The randomly generated string.
        """
        length = 32
        characters = string.ascii_letters + string.digits
        result = ''

        for _ in range(length):
            randomIndex = random.randint(0, len(characters) - 1)
            result += characters[randomIndex]

        return result

    def __get_hmac_signature(self):
        """
        Generates HMAC signature for API authentication.

        Returns:
            computedHmac (str): HMAC signature.
            current_time (int): Current timestamp.
            ClientRequestId (str): Randomly generated client request ID.
        """
        ClientRequestId = self.__generateRandomString()
        current_time = int(time.time())
        rawSignature = self.__api_key + ClientRequestId + str(current_time)

        computedHash = hmac.new(self.__api_secret.encode(), rawSignature.encode(), hashlib.sha256)
        computedHmac = base64.b64encode(computedHash.digest()).decode()
        return computedHmac, current_time, ClientRequestId

    def __create_messages_payload(self, prompt: Union[str, List]):
            """
            Create a messages payload based on the given prompt.

            Args:
                prompt (Union[str, List]): The prompt message or a list of messages.

            Returns:
                List[Dict]: The messages payload.

            """
            messages = []
            if isinstance(prompt, str):
                messages = [
                    {
                        "role": "user",
                        "content": prompt,
                    },
                ]
            else:
                messages = prompt

            if not any(message["role"].lower() == "system" for message in messages):
                messages.insert(0, {
                    "role": "system",
                    "content": self.__DEFAULT_SYSTEM_PROMPT,
                })

            return messages

    def chat_completion_async(self, prompt: Union[str, List]): 
        """
        Asynchronously generates chat completions based on the given prompt.

        Args:
            prompt (Union[str, List]): The prompt for generating chat completions.

        Returns:
            completion_coroutine: The coroutine object for generating chat completions.
        """
        hmac, current_time, ClientRequestId = self.__get_hmac_signature()
        messages = self.__create_messages_payload(prompt)


        completion_coroutine = self.chat.completions.create(
            model="",  # JTE this currently has no effect: it's required by OpenAI lib, but we pass it to our g/w in extra_body 
            extra_headers={"Authorization": hmac, "api-key": self.__api_key, "Timestamp": str(current_time), "Client-Request-Id": ClientRequestId},
            extra_body={"model": self.__model_name},
            max_tokens=self.__MAX_TOKENS,
            messages=messages,
        )

        return completion_coroutine

    def chat_completion(self, prompt: Union[str, List]): 
        """
        Synchronously completes a chat prompt by calling the asynchronous chat_completion_async method.

        Args:
            prompt (Union[str, List]): The chat prompt to be completed.

        Returns:
            str: The completed chat response.
        """
        completion_coroutine = self.chat_completion_async(prompt)

        completion = asyncio.run(completion_coroutine)

        return completion

    def get_models(self) :
        """
            Retrieves the models that are supported by Fiserv AI API.

            Returns:
                list: A list of dictionaries containing the name and label of each model.
        """        
        hmac, current_time, ClientRequestId = self.__get_hmac_signature()

        headers = {
            "api-key": self.__api_key,
            "Client-Request-Id": ClientRequestId,
            "Timestamp": str(current_time),
            "Authorization": hmac,
            "Accept": "application/json",
        }

        response = requests.request("GET", self.__MODELS_URL, headers=headers)

        if response.status_code > 200 :
              raise Exception(f"Failed to get models, status code = {response.status_code}")
        
        # Process the response as needed
        js = response.json()        

        endpoints = [{'name':x['name'], 'label':x['label']} for x in js['data']]
        return endpoints
